<?php
/**
 * Created by PhpStorm.
 * User: Dang Meng
 * Date: 2018/8/11
 * Time: 13:47
 */
return [
    'default_controller'     => 'Index',
    // 默认操作名
    'default_action'         => 'index',
    // 默认验证器
];