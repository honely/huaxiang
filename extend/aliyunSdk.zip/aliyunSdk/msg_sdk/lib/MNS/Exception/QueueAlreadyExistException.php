<?php
namespace AliyunMNS\Exception;

use AliyunMNS\Exception\MnsException;

class QueueAlreadyExistException extends MnsException
{
}

?>
